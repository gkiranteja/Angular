﻿export class Projects {
    id: number;
    pcode: string;
    pname: string;
   // Startd: string;
   // Endd: string;
}