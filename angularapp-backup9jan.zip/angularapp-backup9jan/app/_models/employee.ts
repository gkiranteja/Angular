﻿export class Employee {
    id: number;
    empcode: string;
    empname: string;
}

